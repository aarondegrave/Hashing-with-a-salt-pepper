import hashlib
import csv
import pandas as pd
import webbrowser
import colorama
from colorama import Fore
colorama.init()
pd.set_option('display.max_colwidth', None)

def lookuphash():
  while True:
    
    usernames = input("What is the username? ")
    str = input("What is the password? ")
    df = pd.read_csv("hashes.csv")
    n = pd.read_csv("usernames.csv")
    
  
    salt = df.SALTS[0] 
    hashes = df.HASHES[0]
    username = n.USERNAMES[0]
    
 
    pepper1 = open("customPepper.txt")
    pepper = pepper1.read()
    str2 = (salt + str + pepper)
   
    encoded_message = str2.encode()
    sha512 = hashlib.sha512(encoded_message).hexdigest()


    try:
      if (username == usernames and sha512 == hashes):
        print(Fore.GREEN + "Yes that password is in the csv." + "\n" + Fore.RESET)
        print(sha512 + "\n")
        print(hashes + "\n")
        
        break
     
      elif username != usernames or sha512 != hashes:
        salt = df.SALTS[1]
        hashes = df.HASHES[1]
        username = n.USERNAMES[1]
        str2 = (salt + str + pepper)
        encoded_message = str2.encode()
        sha512 = hashlib.sha512(encoded_message).hexdigest()
      if username == usernames and sha512 == hashes:
        print(Fore.GREEN + "Yes that password is in the csv." + "\n" + Fore.RESET)
        print(sha512 + "\n")
        print(hashes + "\n")

        break
      elif username != usernames or sha512 != hashes:
        salt = df.SALTS[2]
        hashes = df.HASHES[2]
        username = n.USERNAMES[2]
        str2 = (salt + str + pepper)
        encoded_message = str2.encode()
        sha512 = hashlib.sha512(encoded_message).hexdigest()
      if username == usernames and sha512 == hashes:
        print(Fore.GREEN + "Yes that password is in the csv." + "\n" + Fore.RESET)
        print(sha512 + "\n")
        print(hashes + "\n")
    
        break
      elif username != usernames or sha512 != hashes:
        salt = df.SALTS[3]
        hashes = df.HASHES[3]
        username = n.USERNAMES[3]
        str2 = (salt + str + pepper)
        encoded_message = str2.encode()
        sha512 = hashlib.sha512(encoded_message).hexdigest()
      if username == usernames and sha512 == hashes:
        print(Fore.GREEN + "Yes that password is in the csv." + "\n" + Fore.RESET)
        print(sha512 + "\n")
        print(hashes + "\n")
        
        break
      elif username != usernames or sha512 != hashes:
        salt = df.SALTS[4]
        hashes = df.HASHES[4]
        username = n.USERNAMES[4]
        str2 = (salt + str + pepper)
        encoded_message = str2.encode()
        sha512 = hashlib.sha512(encoded_message).hexdigest()
      if username == usernames and sha512 == hashes:
        print(Fore.GREEN + "Yes that password is in the csv." + "\n"+ Fore.RESET)
        print(sha512 + "\n")
        print(hashes + "\n")
        
        break
      else:
        print(Fore.WHITE + "The username or password is wrong." + "\n")

    except KeyError as error:
      print(Fore.WHITE + "The username or password is wrong." + "\n")
      lookuphash()
  