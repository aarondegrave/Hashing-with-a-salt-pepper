import hashlib
import colorama
from colorama import Fore
import random
import string
import csv
import colorama


colorama.init()


def hash():

  ans = True
  while ans:
    username = input("Enter a username: ")
    str = input("Enter a password: ")
    N = 32
    salt = ''.join(random.choices(string.ascii_uppercase + string.digits, k=N))
    pepper1 = open("customPepper.txt")
    pepper = pepper1.read()
    salt_and_pepper_hash = salt + str + pepper
    encoded_str = salt_and_pepper_hash.encode()
    sha512 = hashlib.sha512(encoded_str)
    
    hashlist = {salt: sha512.hexdigest()}
    usernamelist = {username:""}
    
    with open ('hashes.csv', 'a') as f:
      for key in hashlist.keys():
        f.write("%s,%s\n"%(key,hashlist[key]))
    with open ('usernames.csv', 'a') as f:
      for key in usernamelist.keys():
        f.write("%s,%s\n"%(key,usernamelist[key]))
    break
