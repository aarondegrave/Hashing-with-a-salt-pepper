import colorama
from colorama import Fore
from hash import *
from lookup import *


def options():
  ans=True
  while ans:
    print (Fore.LIGHTMAGENTA_EX + """
  1. Add a new word into the csv
  2. Lookup a word in the csv
  3. Exit
    """)
    ans=input("What would you like to do? ") 
    if ans == "1":
      hash()
    elif ans == "2":
      lookuphash()
    elif ans == "3":
      exit()
    else:
      print(Fore.LIGHTRED_EX + "That was not an option.")
      options()
options()
       