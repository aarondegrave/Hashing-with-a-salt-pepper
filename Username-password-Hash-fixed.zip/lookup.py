import hashlib
import csv
import pandas as pd
import colorama
from colorama import Fore
colorama.init()
pd.set_option('display.max_colwidth', None)

def lookuphash():
  while True:
    
    usernames = input("What is the username? ")
    str = input("What is the password? ")
    df = pd.read_csv("hashes.csv")
    n = pd.read_csv("usernames.csv")
    
  
    salt = df.SALTS[0] 
    hashes = df.HASHES[0]
    username = n.USERNAMES[0]
    
 
    pepper1 = open("customPepper.txt")
    pepper = pepper1.read()
    str2 = (salt + str + pepper)
   
    encoded_message = str2.encode()
    sha512 = hashlib.sha512(encoded_message).hexdigest()


    try:
      number = 0
      while True:
      
        if usernames == username and sha512 == hashes:
          print(Fore.GREEN + "Yes that password is in the csv." + "\n" + Fore.RESET)
          print(sha512 + "\n")
          print(hashes + "\n")
          break
        elif sha512 != hashes:
          number = number + 1
          salt = df.SALTS[number]
          hashes = df.HASHES[number]
          username = n.USERNAMES[number]
          str2 = (salt + str + pepper)
          encoded_message = str2.encode()
          sha512 = hashlib.sha512(encoded_message).hexdigest()
          continue
        elif usernames != username:
          number = number + 1
          username = n.USERNAMES[number]
          salt = df.SALTS[number]
          hashes = df.HASHES[number]
          str2 = (salt + str + pepper)
          encoded_message = str2.encode()
          sha512 = hashlib.sha512(encoded_message).hexdigest()
          print(username)
          continue
        else:
          print("That does not exist")
          break
      break

    except KeyError as error:
      print(Fore.WHITE + "The username or password is wrong." + "\n")
      lookuphash()
  